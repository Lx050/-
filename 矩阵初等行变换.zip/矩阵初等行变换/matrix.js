/**
 * 矩阵类，实现矩阵的基本操作和初等行变换
 */
class Matrix {
    /**
     * 创建一个矩阵
     * @param {number} rows - 行数
     * @param {number} cols - 列数
     */
    constructor(rows, cols) {
        this.rows = rows;
        this.cols = cols;
        this.data = [];
        
        // 初始化矩阵，填充为零分数
        for (let i = 0; i < rows; i++) {
            const row = [];
            for (let j = 0; j < cols; j++) {
                row.push(new Fraction(0, 1));
            }
            this.data.push(row);
        }
    }
    
    /**
     * 从数组创建矩阵
     * @param {number[][]} array - 二维数组
     * @returns {Matrix} - 创建的矩阵
     */
    static fromArray(array) {
        if (!array || array.length === 0) return new Matrix(0, 0);
        
        const rows = array.length;
        const cols = array[0].length;
        const matrix = new Matrix(rows, cols);
        
        for (let i = 0; i < rows; i++) {
            for (let j = 0; j < cols; j++) {
                matrix.data[i][j] = new Fraction(array[i][j], 1);
            }
        }
        
        return matrix;
    }
    
    /**
     * 创建矩阵的深拷贝
     * @returns {Matrix} - 矩阵的副本
     */
    clone() {
        const newMatrix = new Matrix(this.rows, this.cols);
        for (let i = 0; i < this.rows; i++) {
            for (let j = 0; j < this.cols; j++) {
                newMatrix.data[i][j] = this.data[i][j].clone();
            }
        }
        return newMatrix;
    }
    
    /**
     * 交换两行
     * @param {number} row1 - 第一行的索引
     * @param {number} row2 - 第二行的索引
     */
    swapRows(row1, row2) {
        if (row1 < 0 || row1 >= this.rows || row2 < 0 || row2 >= this.rows) {
            throw new Error('行索引超出范围');
        }
        
        const temp = this.data[row1];
        this.data[row1] = this.data[row2];
        this.data[row2] = temp;
    }
    
    /**
     * 将某一行乘以一个系数
     * @param {number} row - 行索引
     * @param {Fraction} factor - 乘数
     */
    multiplyRow(row, factor) {
        if (row < 0 || row >= this.rows) {
            throw new Error('行索引超出范围');
        }
        
        for (let j = 0; j < this.cols; j++) {
            this.data[row][j] = this.data[row][j].multiply(factor);
        }
    }
    
    /**
     * 将一行的倍数加到另一行
     * @param {number} sourceRow - 源行索引
     * @param {number} targetRow - 目标行索引
     * @param {Fraction} factor - 倍数
     */
    addMultipleOfRow(sourceRow, targetRow, factor) {
        if (sourceRow < 0 || sourceRow >= this.rows || targetRow < 0 || targetRow >= this.rows) {
            throw new Error('行索引超出范围');
        }
        
        for (let j = 0; j < this.cols; j++) {
            const term = this.data[sourceRow][j].multiply(factor);
            this.data[targetRow][j] = this.data[targetRow][j].subtract(term);
        }
    }
    
    /**
     * 高斯-约旦消元法求行阶梯形矩阵
     * @returns {object} - 包含变换步骤的对象
     */
    gaussJordanElimination() {
        const steps = [];
        const matrix = this.clone();
        
        // 记录初始状态
        steps.push({
            description: '初始矩阵',
            matrix: matrix.clone()
        });
        
        let lead = 0;
        let r = 0;
        
        while (r < matrix.rows && lead < matrix.cols) {
            // 寻找主元
            let i = r;
            while (i < matrix.rows && matrix.data[i][lead].isZero()) {
                i++;
            }
            
            if (i === matrix.rows) {
                // 当前列没有非零元素，移动到下一列
                lead++;
                continue;
            }
            
            // 如果主元不在当前行，交换行
            if (i !== r) {
                matrix.swapRows(i, r);
                steps.push({
                    description: `交换第${r + 1}行和第${i + 1}行`,
                    matrix: matrix.clone()
                });
            }
            
            // 将主元归一化
            const factor = matrix.data[r][lead];
            if (!(factor.numerator === 1 && factor.denominator === 1)) {
                const normalizeFactor = new Fraction(factor.denominator, factor.numerator);
                matrix.multiplyRow(r, normalizeFactor);
                steps.push({
                    description: `第${r + 1}行 × ${normalizeFactor.toString()} （归一化主元）`,
                    matrix: matrix.clone()
                });
            }
            
            // 消元过程
            for (let i = 0; i < matrix.rows; i++) {
                if (i !== r && !matrix.data[i][lead].isZero()) {
                    const k = matrix.data[i][lead];
                    matrix.addMultipleOfRow(r, i, k);
                    steps.push({
                        description: `第${r + 1}行 × ${k.toString()} 加到第${i + 1}行`,
                        matrix: matrix.clone()
                    });
                }
            }
            
            r++;
            lead++;
        }
        
        // 整理零行
        let nzr = 0;
        for (let j = 0; j < matrix.cols; j++) {
            for (let i = nzr; i < matrix.rows; i++) {
                if (!matrix.data[i][j].isZero()) {
                    if (i !== nzr) {
                        matrix.swapRows(i, nzr);
                        steps.push({
                            description: `整理零行：交换第${nzr + 1}行和第${i + 1}行`,
                            matrix: matrix.clone()
                        });
                    }
                    nzr++;
                    break;
                }
            }
        }
        
        return {
            finalMatrix: matrix,
            steps: steps
        };
    }
}