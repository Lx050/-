/**
 * 分数类，用于矩阵中的精确计算
 */
class Fraction {
    /**
     * 创建一个分数
     * @param {number} numerator - 分子
     * @param {number} denominator - 分母，默认为1
     */
    constructor(numerator = 0, denominator = 1) {
        if (denominator === 0) denominator = 1;
        
        // 计算最大公约数并约分
        const gcd = this.gcd(Math.abs(numerator), Math.abs(denominator));
        this.numerator = numerator / gcd;
        this.denominator = denominator / gcd;
        
        // 确保分母为正数
        if (this.denominator < 0) {
            this.numerator *= -1;
            this.denominator *= -1;
        }
    }
    
    /**
     * 计算最大公约数
     * @param {number} a - 第一个数
     * @param {number} b - 第二个数
     * @returns {number} - 最大公约数
     */
    gcd(a, b) {
        if (b === 0) return a;
        return this.gcd(b, a % b);
    }
    
    /**
     * 将分数转换为字符串表示
     * @returns {string} - 分数的字符串表示
     */
    toString() {
        if (this.denominator === 1) return this.numerator.toString();
        return `${this.numerator}/${this.denominator}`;
    }
    
    /**
     * 加法运算
     * @param {Fraction} other - 另一个分数
     * @returns {Fraction} - 加法结果
     */
    add(other) {
        const num = this.numerator * other.denominator + other.numerator * this.denominator;
        const den = this.denominator * other.denominator;
        return new Fraction(num, den);
    }
    
    /**
     * 减法运算
     * @param {Fraction} other - 另一个分数
     * @returns {Fraction} - 减法结果
     */
    subtract(other) {
        const num = this.numerator * other.denominator - other.numerator * this.denominator;
        const den = this.denominator * other.denominator;
        return new Fraction(num, den);
    }
    
    /**
     * 乘法运算
     * @param {Fraction} other - 另一个分数
     * @returns {Fraction} - 乘法结果
     */
    multiply(other) {
        const num = this.numerator * other.numerator;
        const den = this.denominator * other.denominator;
        return new Fraction(num, den);
    }
    
    /**
     * 除法运算
     * @param {Fraction} other - 另一个分数
     * @returns {Fraction} - 除法结果
     */
    divide(other) {
        const num = this.numerator * other.denominator;
        const den = this.denominator * other.numerator;
        return new Fraction(num, den);
    }
    
    /**
     * 判断分数是否为零
     * @returns {boolean} - 如果分数为零则返回true
     */
    isZero() {
        return this.numerator === 0;
    }
    
    /**
     * 创建分数的副本
     * @returns {Fraction} - 分数的副本
     */
    clone() {
        return new Fraction(this.numerator, this.denominator);
    }
}