/**
 * 矩阵初等行变换可视化应用
 */

// DOM元素
const rowsInput = document.getElementById('rows');
const colsInput = document.getElementById('cols');
const createMatrixBtn = document.getElementById('create-matrix');
const startTransformBtn = document.getElementById('start-transform');
const prevStepBtn = document.getElementById('prev-step');
const nextStepBtn = document.getElementById('next-step');
const autoPlayBtn = document.getElementById('auto-play');
const stepCounter = document.getElementById('step-counter');
const stepDescription = document.getElementById('step-description');
const matrixInputContainer = document.getElementById('matrix-input-container');
const matrixDisplay = document.getElementById('matrix-display');
const matrixImageInput = document.getElementById('matrix-image'); // 新增
const recognizeMatrixBtn = document.getElementById('recognize-matrix'); // 新增
const ocrStatus = document.getElementById('ocr-status'); // 新增

// 应用状态
let currentMatrix = null;
let transformationSteps = [];
let currentStepIndex = 0;
let autoPlayInterval = null;

// 初始化事件监听器
function initEventListeners() {
    createMatrixBtn.addEventListener('click', createMatrixInputs);
    startTransformBtn.addEventListener('click', startTransformation);
    prevStepBtn.addEventListener('click', showPreviousStep);
    nextStepBtn.addEventListener('click', showNextStep);
    autoPlayBtn.addEventListener('click', toggleAutoPlay);
    recognizeMatrixBtn.addEventListener('click', recognizeMatrixFromImage); // 新增
}

/**
 * 创建矩阵输入界面
 */
function createMatrixInputs() {
    const rows = parseInt(rowsInput.value);
    const cols = parseInt(colsInput.value);
    
    if (isNaN(rows) || isNaN(cols) || rows < 1 || cols < 1 || rows > 10 || cols > 10) {
        alert('请输入有效的行数和列数（1-10）');
        return;
    }
    
    matrixInputContainer.innerHTML = '';
    
    for (let i = 0; i < rows; i++) {
        const rowDiv = document.createElement('div');
        rowDiv.className = 'matrix-row';
        
        for (let j = 0; j < cols; j++) {
            const cellDiv = document.createElement('div');
            cellDiv.className = 'matrix-cell';
            
            const input = document.createElement('input');
            input.type = 'text';
            input.dataset.row = i;
            input.dataset.col = j;
            input.value = '0';
            
            // 添加键盘事件监听
            input.addEventListener('keydown', handleMatrixInputKeydown);
            
            cellDiv.appendChild(input);
            rowDiv.appendChild(cellDiv);
        }
        
        matrixInputContainer.appendChild(rowDiv);
    }
    
    startTransformBtn.disabled = false;
}

/**
 * 处理矩阵输入框的键盘事件
 * @param {KeyboardEvent} event - 键盘事件对象
 */
function handleMatrixInputKeydown(event) {
    const currentInput = event.target;
    const currentRow = parseInt(currentInput.dataset.row);
    const currentCol = parseInt(currentInput.dataset.col);
    const rows = parseInt(rowsInput.value);
    const cols = parseInt(colsInput.value);
    
    let nextInput = null;
    
    switch (event.key) {
        case 'ArrowUp':
            if (currentRow > 0) {
                nextInput = document.querySelector(`input[data-row="${currentRow - 1}"][data-col="${currentCol}"]`);
            }
            break;
        case 'ArrowDown':
            if (currentRow < rows - 1) {
                nextInput = document.querySelector(`input[data-row="${currentRow + 1}"][data-col="${currentCol}"]`);
            }
            break;
        case 'ArrowLeft':
            if (currentCol > 0) {
                nextInput = document.querySelector(`input[data-row="${currentRow}"][data-col="${currentCol - 1}"]`);
            }
            break;
        case 'ArrowRight':
        case ' ': // 空格键
            if (currentCol < cols - 1) {
                nextInput = document.querySelector(`input[data-row="${currentRow}"][data-col="${currentCol + 1}"]`);
            } else if (currentRow < rows - 1) {
                // 如果是最后一列，跳转到下一行第一列
                nextInput = document.querySelector(`input[data-row="${currentRow + 1}"][data-col="0"]`);
            }
            if (event.key === ' ') {
                event.preventDefault(); // 阻止空格键的默认行为
            }
            break;
    }
    
    if (nextInput) {
        nextInput.focus();
        nextInput.select(); // 选中输入框中的文本
    }
}

/**
 * 从输入框读取矩阵数据
 * @returns {number[][]} 矩阵数据
 */
function readMatrixFromInputs() {
    const rows = parseInt(rowsInput.value);
    const cols = parseInt(colsInput.value);
    const matrixData = [];
    
    for (let i = 0; i < rows; i++) {
        const rowData = [];
        for (let j = 0; j < cols; j++) {
            const input = document.querySelector(`input[data-row="${i}"][data-col="${j}"]`);
            let value = parseInt(input.value);
            if (isNaN(value)) value = 0;
            rowData.push(value);
        }
        matrixData.push(rowData);
    }
    
    return matrixData;
}

/**
 * 从图片识别矩阵并填充输入框
 */
async function recognizeMatrixFromImage() {
    const file = matrixImageInput.files[0];
    if (!file) {
        alert('请先选择一个图片文件');
        return;
    }

    ocrStatus.textContent = '正在识别图片...';
    recognizeMatrixBtn.disabled = true;

    try {
        const { data: { text } } = await Tesseract.recognize(
            file,
            'eng', // 假设图片中的数字是英文格式
            {
                logger: m => {
                    console.log(m); // 可以在控制台查看识别进度
                    if (m.status === 'recognizing text') {
                        ocrStatus.textContent = `正在识别... ${Math.round(m.progress * 100)}%`;
                    }
                }
            }
        );

        console.log('OCR Result:', text);
        ocrStatus.textContent = '识别完成，正在解析矩阵...';

        // 解析识别出的文本
        const lines = text.trim().split('\n');
        const matrixData = [];
        let cols = 0;

        for (const line of lines) {
            // 尝试用空格、制表符或逗号分割数字
            const nums = line.trim().split(/[\s,]+/);
            const rowData = [];
            for (const numStr of nums) {
                // 尝试解析为分数或整数
                try {
                    // 简单处理，只接受整数或简单分数形式如 a/b
                    if (numStr.includes('/')) {
                        const parts = numStr.split('/');
                        if (parts.length === 2 && !isNaN(parseInt(parts[0])) && !isNaN(parseInt(parts[1]))) {
                             // 为了简化，我们先只填入分子，或者可以尝试用 Fraction.js 解析
                             // 这里暂时只填入原始字符串，让用户手动修正
                            rowData.push(numStr); 
                        } else {
                            rowData.push('?'); //无法解析的分数
                        }
                    } else if (!isNaN(parseInt(numStr))) {
                        rowData.push(parseInt(numStr).toString());
                    } else {
                         rowData.push('?'); //无法解析的字符
                    }
                } catch (e) {
                    rowData.push('?'); // 解析出错
                }
            }
            if (rowData.length > 0) {
                matrixData.push(rowData);
                if (rowData.length > cols) {
                    cols = rowData.length;
                }
            }
        }

        // 确保所有行的列数一致
        const rows = matrixData.length;
        if (rows === 0 || cols === 0) {
             throw new Error('无法从图片中解析出有效的矩阵结构。');
        }

        for(let i = 0; i < rows; i++) {
            while (matrixData[i].length < cols) {
                matrixData[i].push('0'); // 用0填充缺失的列
            }
            matrixData[i] = matrixData[i].slice(0, cols); // 截断多余的列
        }

        // 更新行数和列数输入框
        rowsInput.value = rows;
        colsInput.value = cols;

        // 创建新的矩阵输入框
        createMatrixInputs();

        // 填充矩阵输入框
        for (let i = 0; i < rows; i++) {
            for (let j = 0; j < cols; j++) {
                const input = document.querySelector(`input[data-row="${i}"][data-col="${j}"]`);
                if (input && matrixData[i][j] !== undefined) {
                    input.value = matrixData[i][j];
                }
            }
        }

        ocrStatus.textContent = `成功从图片填充 ${rows}x${cols} 矩阵。请检查数值是否正确。`;

    } catch (error) {
        console.error('OCR Error:', error);
        ocrStatus.textContent = `识别失败: ${error.message || '未知错误'}`;
        alert('图片识别失败，请检查图片内容或尝试其他图片。错误信息：' + error);
    } finally {
        recognizeMatrixBtn.disabled = false;
    }
}


/**
 * 开始矩阵变换
 */
function startTransformation() {
    const matrixData = readMatrixFromInputs();
    if (!matrixData.length) return;
    
    currentMatrix = Matrix.fromArray(matrixData);
    const result = currentMatrix.gaussJordanElimination();
    transformationSteps = result.steps;
    
    // 重置状态
    currentStepIndex = 0;
    updateStepCounter();
    displayCurrentStep();
    
    // 启用控制按钮
    prevStepBtn.disabled = true; // 初始步骤，上一步按钮禁用
    nextStepBtn.disabled = transformationSteps.length <= 1;
    autoPlayBtn.disabled = transformationSteps.length <= 1;
    
    // 显示变换部分
    document.querySelector('.transformation-section').style.display = 'block';
}

/**
 * 显示当前步骤的矩阵
 */
function displayCurrentStep() {
    if (!transformationSteps.length) return;
    
    const step = transformationSteps[currentStepIndex];
    stepDescription.textContent = step.description;
    
    // 显示矩阵
    displayMatrix(step.matrix);
}

/**
 * 在界面上显示矩阵
 * @param {Matrix} matrix - 要显示的矩阵
 */
function displayMatrix(matrix) {
    matrixDisplay.innerHTML = '';
    
    for (let i = 0; i < matrix.rows; i++) {
        const rowDiv = document.createElement('div');
        rowDiv.className = 'matrix-row';
        
        for (let j = 0; j < matrix.cols; j++) {
            const cellDiv = document.createElement('div');
            cellDiv.className = 'matrix-cell';
            cellDiv.textContent = matrix.data[i][j].toString();
            rowDiv.appendChild(cellDiv);
        }
        
        matrixDisplay.appendChild(rowDiv);
    }
}

/**
 * 显示上一步
 */
function showPreviousStep() {
    if (currentStepIndex > 0) {
        currentStepIndex--;
        updateStepCounter();
        displayCurrentStep();
        
        // 更新按钮状态
        nextStepBtn.disabled = false;
        prevStepBtn.disabled = currentStepIndex === 0;
    }
}

/**
 * 显示下一步
 */
function showNextStep() {
    if (currentStepIndex < transformationSteps.length - 1) {
        currentStepIndex++;
        updateStepCounter();
        displayCurrentStep();
        
        // 更新按钮状态
        prevStepBtn.disabled = false;
        nextStepBtn.disabled = currentStepIndex === transformationSteps.length - 1;
    }
}

/**
 * 更新步骤计数器
 */
function updateStepCounter() {
    stepCounter.textContent = `步骤: ${currentStepIndex + 1}/${transformationSteps.length}`;
}

/**
 * 切换自动播放
 */
function toggleAutoPlay() {
    if (autoPlayInterval) {
        // 停止自动播放
        clearInterval(autoPlayInterval);
        autoPlayInterval = null;
        autoPlayBtn.textContent = '自动播放';
    } else {
        // 开始自动播放
        autoPlayBtn.textContent = '停止播放';
        autoPlayInterval = setInterval(() => {
            if (currentStepIndex < transformationSteps.length - 1) {
                showNextStep();
            } else {
                // 播放完毕，停止自动播放
                clearInterval(autoPlayInterval);
                autoPlayInterval = null;
                autoPlayBtn.textContent = '自动播放';
            }
        }, 1000); // 每秒播放一步
    }
}

// 页面加载完成后初始化应用
document.addEventListener('DOMContentLoaded', () => {
    initEventListeners();
});