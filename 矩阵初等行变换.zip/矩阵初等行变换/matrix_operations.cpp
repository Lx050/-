#include<bits/stdc++.h>
using namespace std;

#define int long long
#define endl "\n"

struct Fraction 
{
    int numerator;
    int denominator;

    Fraction(int num = 0, int den = 1) 
	{
        if (den == 0) den = 1;
        int gcd_val = __gcd(abs(num), abs(den));
        numerator = num / gcd_val;
        denominator = den / gcd_val;
        if (denominator < 0) 
		{
            numerator *= -1;
            denominator *= -1;
        }
    }

    string str() const 
	{
        if (denominator == 1) return to_string(numerator);
        return to_string(numerator) + "/" + to_string(denominator);
    }
};

vector<vector<Fraction>> current_matrix;
vector<pair<string, vector<vector<Fraction>>>> steps;

Fraction operator+(const Fraction& a, const Fraction& b) 
{
    int num = a.numerator * b.denominator + b.numerator * a.denominator;
    int den = a.denominator * b.denominator;
    return Fraction(num, den);
}

Fraction operator-(const Fraction& a, const Fraction& b) 
{
    int num = a.numerator * b.denominator - b.numerator * a.denominator;
    int den = a.denominator * b.denominator;
    return Fraction(num, den);
}

Fraction operator*(const Fraction& a, const Fraction& b) 
{
    int num = a.numerator * b.numerator;
    int den = a.denominator * b.denominator;
    return Fraction(num, den);
}

Fraction operator/(const Fraction& a, const Fraction& b) 
{
    int num = a.numerator * b.denominator;
    int den = a.denominator * b.numerator;
    return Fraction(num, den);
}

bool zero(const Fraction& f) 
{
    return f.numerator == 0;
}

void record_step(const string& desc) 
{
    steps.emplace_back(desc, current_matrix);
}

void print_matrix(const vector<vector<Fraction>>& mat) 
{
    for (const auto& row : mat) 
	{
        for (const auto& elem : row) 
		{
            cout << setw(8) << elem.str() << " ";
        }
        cout << endl;
    }
}
void solve() 
{
    steps.clear();
    int n, m;
    cout << endl << "请输入矩阵的行和列:  ";
    cin >> n >> m;

    current_matrix.resize(n, vector<Fraction>(m));
    for(int i = 0; i < n; i++)
        for(int j = 0; j < m; j++) 
		{
            int num;
            cin >> num;
            current_matrix[i][j] = Fraction(num, 1);
        }

    record_step("初始矩阵");
    
    int lead = 0;
    int r = 0; 
    while (r < n && lead < m) 
	{
        int i = r;
        while (i < n && zero(current_matrix[i][lead])) i++;
        
        if (i == n) 
		{ 
            lead++; 
            continue;
        }

        if(i != r) 
		{
            swap(current_matrix[i], current_matrix[r]);
            record_step("交换第" + to_string(r + 1) + "行和第" + to_string(i + 1) + "行");
        }

        Fraction factor = current_matrix[r][lead];
        if(!(factor.numerator == 1 && factor.denominator == 1)) 
		{
            string op = "第" + to_string(r+1) + "行 × " 
                       + to_string(factor.denominator) + "/"
                       + to_string(factor.numerator)
                       + " （归一化主元）";
            for(int j = lead; j < m; j++)
                current_matrix[r][j] = current_matrix[r][j] / factor;
            record_step(op);
        }

        for(int i = 0; i < n; i++) 
		{
            if(i != r && !zero(current_matrix[i][lead])) 
			{
                Fraction k = current_matrix[i][lead];
                string op = "第" + to_string(r+1) + "行 × " + k.str() 
                           + " 加到第" + to_string(i+1) + "行";
                for(int j = lead; j < m; j++)
                    current_matrix[i][j] = current_matrix[i][j] - k * current_matrix[r][j];
                record_step(op);
            }
        }

        r++;
        lead++;
    }
    int nzr = 0;
    for (int j = 0; j < m; j++) 
	{
        for (int i = nzr; i < n; i++) 
		{
            if (!zero(current_matrix[i][j])) 
			{
                if (i != nzr) 
				{
                    swap(current_matrix[i], current_matrix[nzr]);
                    record_step("整理零行：交换第" + to_string(nzr + 1) 
                              + "行和第" + to_string(i+1) + "行");
                }
                nzr++;
                break;
            }
        }
    }
    cout << endl << "共进行了" << steps.size() - 1 << "次变换：" << endl;
    for(int i = 0; i < steps.size(); i++) 
	{
        cout << endl << "步骤 " << i + 1 << ": " << steps[i].first << endl;
        print_matrix(steps[i].second);
    }
}

signed main() 
 {
    int t;
    cout << "请输入待解决题目数：";
    cin >> t;
    while(t--) solve();
    return 0;
}